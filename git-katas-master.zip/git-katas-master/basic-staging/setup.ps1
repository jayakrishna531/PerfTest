. ..\utils\make-exercise-repo.ps1

Set-Content -Value "1" -Path file.txt

git add file.txt
git commit -m "1"
