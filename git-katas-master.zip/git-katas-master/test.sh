cd basic-commits
./setup.sh
cd ..