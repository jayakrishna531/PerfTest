Add notes for trainer here.
