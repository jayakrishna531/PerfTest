

def merge_sort(m):
	"""Sort list m, using merge sort"""
	return m.sort() # TODO: Replace with actual implementation
