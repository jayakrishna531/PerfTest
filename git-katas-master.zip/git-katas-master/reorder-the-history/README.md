# gitkatas
## Kata 7: Reordering history
The commits here has obviously been made by a mad man.
Unfortunately they actually contain useful information - it's just that the history is weird.
You should fix this such that our `git log` looks great!

## Setup

1. Run `. setup.sh` (or `.\setup.ps1` in PowerShell)

## Task

1. Reorder the history such that it actually makes sense

### useful commands

- `git rebase -i`
- `git reflog`
