. ..\utils\make-exercise-repo.ps1

Set-Content -Value "hello" -Path file1.txt

git init
git checkout -b master
