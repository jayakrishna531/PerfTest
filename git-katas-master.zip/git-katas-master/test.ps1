cd basic-commits
.\setup.ps1
cd ..