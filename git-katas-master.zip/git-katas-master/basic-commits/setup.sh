#!/bin/bash
kata="basic-commits-master"
source ../utils/utils.sh
makerepo
